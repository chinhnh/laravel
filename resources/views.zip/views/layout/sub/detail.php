<!DOCTYPE HTML>
<html>
    <head>
        <meta http-equiv="content-type" content="text/html" />
        <meta name="author" content="lolkittens" />

        <title><?php echo "$title"; ?></title>
    </head>

    <body>

        <table>
            <tr>
                <th>tên</th>
                <th>tuổi</th>
            </tr>
            <tr>
                <th>a</th>
                <th>34</th>
            </tr>
            <tr>
                <th>b</th>
                <th>534</th>
            </tr>
            <tr>
                <th>ghf</th>
                <th>5345</th>
            </tr>
            <tr>
                <th>cvc</th>
                <th>45764</th>
            </tr>
        </table>

    </body>
</html>
<style>

    th{
        color: red;border:1px solid black;
    }


</style>