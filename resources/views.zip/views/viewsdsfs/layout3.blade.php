@extends('views.layout')
@section('title','dfhdsfhh')
@section('content')
layout 3
@stop
@section('header')
@parent
3
@stop