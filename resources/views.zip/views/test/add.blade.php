<p>đây là trang add</p>
<?php
echo 'Ban dang xem san pham ' . $name . ' có giá = ' . $gia;
?>