<p>test view</p>
<a href="./san-pham/test2/chinh/1111"> click</a>
<?php
//$results = DB::select('select * from tbl_nhanvien '); 
//print_r($results);
?>