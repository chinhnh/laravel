<?php
echo $name['sp1'];
foreach ($name as $row) {
    //echo $row[0]['sp1'];
}
?>
<a href="<?php ?>"></a>