trang call view
<?php
echo $hoten;
?>