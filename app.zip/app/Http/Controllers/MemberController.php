<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\Login;

class MemberController extends Controller
{

    public function getlogin()
    {
        return view('login');
    }

    public function postlogin(Login $request)
    {
        
    }
}
